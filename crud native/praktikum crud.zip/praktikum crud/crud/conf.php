<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'prak_db';

$conn = mysqli_connect($host, $username, $password, $dbname);
// if (!$conn) {
//     echo "Koneksi ke database gagal". mysqli_connect_error();
//     die();
// } else {
//     echo "Koneksi ke database berhasil";
// }
?>